package com.probie.jvavser.Data;

import com.probie.easydb.EasyDB;
import com.probie.easydb.Database.Local.LocalDB;

public class Data {

    private final static String[] WELCOME_MESSAGE = new String[] {
            "HEY!",
            "I AM JVAVSER!!",
            "WHO WANT TO EAT YOUR FLAG!!!"
    };

    private final static String INPUT_FLAG_MESSAGE = "I WILL NOT WAIT YOU ANY MORE TIME: ";

    private final static String RIGHT_FLAG_MESSAGE = "LET YOU OFF THE HOOK!";

    private final static String WRONG_FLAG_MESSAGE = "THAT IS NOT WHAT I NEED!!!";

    private final static String FLAG_MESSAGE = "SO HUNGRY YOU TOO!!! SHARED YOU ARE MINE: ";
    private final static String FLAG = "Y0d0M2MyVmplemRvTVRWZk1UVmZORjlHTkdzelgwWXhORFpmV1RCMVgwdHVNSGRmTUc4d1B5RitmUT09";

    private final static String JDK_VERSION = "21.0.8";
    private static String C = "C";

    public static String[] getWelcomeMessage() {
        return WELCOME_MESSAGE;
    }

    public static String getInputFlagMessage() {
        return INPUT_FLAG_MESSAGE;
    }

    public static String getRightFlagMessage() {
        return RIGHT_FLAG_MESSAGE;
    }

    public static String getWrongFlagMessage() {
        return WRONG_FLAG_MESSAGE;
    }

    public static String getFlagMessage() {
        return FLAG_MESSAGE;
    }

    public static String getFLAG() {
        return FLAG;
    }

    public static String getJdkVersion() {
        return JDK_VERSION;
    }

    public static void setC(String C) {
        Data.C = C;
    }

    public static String getC() {
        try (LocalDB localDB = EasyDB.getInstance().getLocalDatabaseFactory().buildLocalDB()) {
            if (localDB.connect(ClassLoader.getSystemResourceAsStream("C"))) {
                localDB.setIsAutoCommit(false);
                setC(new com.probie.easydb.DataPacket.Data().deCode(localDB.get("c")).get("c").toString());
            }
        }
        return Data.C;
    }

}