package com.probie.easydb;

import com.probie.easydb.Database.Local.LocalDatabaseFactory;

public class EasyDB {

    private volatile static EasyDB INSTANCE;

    /**
     * 获取 EasyDB 的单例对象
     * */
    public synchronized static EasyDB getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new EasyDB();
        }
        return INSTANCE;
    }

    /**
     * 构造一个本地数据库
     * */
    public LocalDatabaseFactory getLocalDatabaseFactory() {
        return LocalDatabaseFactory.getInstance();
    }

}