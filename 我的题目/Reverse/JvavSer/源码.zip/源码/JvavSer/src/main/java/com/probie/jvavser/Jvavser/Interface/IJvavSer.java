package com.probie.jvavser.Jvavser.Interface;

import java.util.Scanner;
import com.probie.jvavser.Data.Data;
import com.probie.encryption.Encryption;

public interface IJvavSer {

    /**
     * 启动程序
     * @param args Args From Main
     * */
    default int launch(String[] args) {
        for (String welcomeMessage : Data.getWelcomeMessage()) {
            System.out.println(welcomeMessage);
        }
        System.out.printf("%s", Data.getInputFlagMessage());
        Scanner scanner = new Scanner(System.in);
        if (scanner.hasNext()) {
            String flag = scanner.next();
            if (!Encryption.getInstance().isDebug()) {
                if (flag.contains("{") && flag.contains("}")) {
                    String format = flag.split("\\{")[0];
                    if (format.toUpperCase().toLowerCase().equalsIgnoreCase("pkwsec")) {
                        Encryption.getInstance().getConfigFactory().getKeyConfig().getLocalDB().connect(ClassLoader.getSystemResourceAsStream("Key"));
                        Encryption.getInstance().getConfigFactory().getKeyConfig().getLocalDB().setIsAutoCommit(false);
                        flag = Encryption.getInstance().getEncrypterFactory().getMapEncrypter().encryptByMap(
                                Encryption.getInstance().getEncoderFactory().getSerializeEncoder().encodeSerialize(
                                        Encryption.getInstance().getEncoderFactory().getBase64Encoder().encodeBase64(
                                                Encryption.getInstance().getEncoderFactory().getCaesarEncoder().encodeCaesar(
                                                        Encryption.getInstance().getEncoderFactory().getXOEncoder().encodeXO(
                                                                flag.substring(flag.indexOf("{") + 1, flag.lastIndexOf("}"))
                                                        )
                                                )
                                        )
                                )
                        );
                        if (flag.equals(Data.getC())) {
                            System.out.println(Data.getRightFlagMessage());
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException interruptedException) {
                                throw new RuntimeException(interruptedException);
                            }
                            return 0;
                        }
                    }
                }
            } else {
                System.out.println(Data.getFlagMessage()+Data.getFLAG());
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException interruptedException) {
                    throw new RuntimeException(interruptedException);
                }
                return 0;
            }
        }
        System.out.println(Data.getWrongFlagMessage());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException interruptedException) {
            throw new RuntimeException(interruptedException);
        }
        return 0;
    }

}