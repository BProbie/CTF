package com.probie.jvavser;

import java.io.File;
import com.probie.easydb.EasyDB;
import com.probie.jvavser.Data.Data;
import com.probie.encryption.Encryption;
import com.probie.jvavser.Jvavser.JvavSer;
import com.probie.easydb.Database.Local.LocalDB;

public class Main {

    public static void main(String[] args) {
        JvavSer.getInstance().launch(args);

//        String flag = "pkwsec{3718ad6bc71cfa7084df1a9258c165b086f0405be010e6eae37127b70ceaa3eb}";
//        flag = flag.substring(flag.indexOf("{") + 1, flag.lastIndexOf("}"));
//        flag = Encryption.getInstance().getEncrypterFactory().getMapEncrypter().encryptByMap(
//                Encryption.getInstance().getEncoderFactory().getSerializeEncoder().encodeSerialize(
//                        Encryption.getInstance().getEncoderFactory().getBase64Encoder().encodeBase64(
//                                Encryption.getInstance().getEncoderFactory().getCaesarEncoder().encodeCaesar(
//                                        Encryption.getInstance().getEncoderFactory().getXOEncoder().encodeXO(flag)
//                                )
//                        )
//                )
//        );
//        com.probie.easydb.DataPacket.Data data = new com.probie.easydb.DataPacket.Data();
//        data.put("c", flag);
//        try (LocalDB localDB = EasyDB.getInstance().getLocalDatabaseFactory().buildLocalDB()) {
//            localDB.setFullFilePath(localDB.getPath()+File.separator+"C");
//            localDB.set("c", data.enCode());
//        }
//        System.out.println(Data.getC());

    }

}