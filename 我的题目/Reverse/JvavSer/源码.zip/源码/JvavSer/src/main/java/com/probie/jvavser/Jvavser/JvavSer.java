package com.probie.jvavser.Jvavser;

import com.probie.jvavser.Jvavser.Interface.IJvavSer;

public class JvavSer implements IJvavSer {

    private volatile static JvavSer INSTANCE;

    public synchronized static JvavSer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new JvavSer();
        }
        return INSTANCE;
    }

}