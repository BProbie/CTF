package com.probie.encryption.Decoder;

public class DecoderFactory {

    private volatile static DecoderFactory INSTANCE;

    public synchronized static DecoderFactory getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new DecoderFactory();
        }
        return INSTANCE;
    }

    public SerializeDecoder getSerializeEncoder() {
        return SerializeDecoder.getInstance();
    }

}